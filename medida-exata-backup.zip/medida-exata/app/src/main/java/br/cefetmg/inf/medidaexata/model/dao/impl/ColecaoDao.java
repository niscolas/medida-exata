package br.cefetmg.inf.medidaexata.model.dao.impl;

import com.google.firebase.firestore.CollectionReference;

import br.cefetmg.inf.medidaexata.model.dao.IColecaoDao;

public class ColecaoDao implements IColecaoDao {
    @Override
    public CollectionReference busca(String caminho) {
        return null;
    }
}
