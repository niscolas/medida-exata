# medida-exata
Repositório referente ao aplicativo Medida Exata, feito pela Equipe INFalíveis para a Maratona Brasil Mais TI
